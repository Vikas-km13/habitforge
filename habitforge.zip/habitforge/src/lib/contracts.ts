export const FREQUENCIES = ["DAILY", "WEEKLY"] as const;
export type Frequency = (typeof FREQUENCIES)[number];

export const SUBSCRIPTION_TIERS = ["FREE", "PREMIUM"] as const;
export type SubscriptionTier = (typeof SUBSCRIPTION_TIERS)[number];

export type UserSummary = {
  id: string;
  displayName: string;
  subscriptionTier: SubscriptionTier;
  shareProgress: boolean;
  level: number;
  points: number;
};

export type HabitItem = {
  id: string;
  name: string;
  description: string | null;
  color: string;
  frequency: Frequency;
  targetCount: number;
  periodProgress: number;
  isCompletedThisPeriod: boolean;
  currentStreak: number;
  longestStreak: number;
  totalMilestones: number;
  lastLoggedAt: string | null;
};

export type DashboardData = {
  user: {
    id: string;
    displayName: string;
    subscriptionTier: SubscriptionTier;
    shareProgress: boolean;
    points: number;
    level: number;
    currentStreak: number;
    longestStreak: number;
    totalCompletions: number;
  };
  summary: {
    activeHabits: number;
    completionRateThisWeek: number;
    achievementsUnlocked: number;
  };
  habits: HabitItem[];
  achievements: {
    key: string;
    title: string;
    description: string;
    unlockedAt: string;
  }[];
  charts: {
    labels: string[];
    completionSeries: number[];
    pointSeries: number[];
  };
  leaderboard: {
    id: string;
    displayName: string;
    level: number;
    points: number;
  }[];
};

export type PremiumAnalyticsData = {
  consistencyByHabit: {
    habitId: string;
    habitName: string;
    frequency: Frequency;
    score: number;
  }[];
  bestDayOfWeek: string;
  strongestHabit: string;
  totalPointsLast30Days: number;
};

export type PremiumResource = {
  title: string;
  type: "guide" | "template" | "challenge";
  duration: string;
  description: string;
};
