import { subDays } from "date-fns";
import type { Frequency, SubscriptionTier } from "@/lib/contracts";
import { dayKey, getPeriodStart, getPreviousPeriodStart, isConsecutivePeriod } from "@/lib/period";

export type AchievementDefinition = {
  key: string;
  title: string;
  description: string;
  predicate: (context: AchievementContext) => boolean;
};

export type AchievementContext = {
  points: number;
  totalCompletions: number;
  longestStreak: number;
  habitCount: number;
  shareProgress: boolean;
  daysActiveLast7: number;
  subscriptionTier: SubscriptionTier;
};

export const ACHIEVEMENTS: AchievementDefinition[] = [
  {
    key: "first_completion",
    title: "First Spark",
    description: "Complete your first habit milestone.",
    predicate: (context) => context.totalCompletions >= 1,
  },
  {
    key: "week_warrior",
    title: "Week Warrior",
    description: "Maintain a 7-day streak.",
    predicate: (context) => context.longestStreak >= 7,
  },
  {
    key: "streak_titan",
    title: "Streak Titan",
    description: "Reach an epic 30-day streak.",
    predicate: (context) => context.longestStreak >= 30,
  },
  {
    key: "habit_architect",
    title: "Habit Architect",
    description: "Create 3 habits.",
    predicate: (context) => context.habitCount >= 3,
  },
  {
    key: "habit_legend",
    title: "Habit Legend",
    description: "Create 8 habits.",
    predicate: (context) => context.habitCount >= 8,
  },
  {
    key: "social_accountability",
    title: "Social Challenger",
    description: "Share your progress with the community leaderboard.",
    predicate: (context) => context.shareProgress,
  },
  {
    key: "consistency_ace",
    title: "Consistency Ace",
    description: "Be active on 5 of the last 7 days.",
    predicate: (context) => context.daysActiveLast7 >= 5,
  },
  {
    key: "premium_pathfinder",
    title: "Premium Pathfinder",
    description: "Unlock premium mode.",
    predicate: (context) => context.subscriptionTier === "PREMIUM",
  },
  {
    key: "xp_500",
    title: "XP Vanguard",
    description: "Collect 500 total points.",
    predicate: (context) => context.points >= 500,
  },
];

export function calculateLevel(points: number): number {
  return Math.max(1, Math.floor(Math.sqrt(points / 120)) + 1);
}

export function pointsForCompletion(streak: number): number {
  const basePoints = 10;
  const streakBonus = Math.min(streak, 10) * 2;
  return basePoints + streakBonus;
}

export function getStreakStats(
  periodStarts: Date[],
  frequency: Frequency,
  referenceDate: Date = new Date(),
): { current: number; longest: number } {
  if (periodStarts.length === 0) {
    return { current: 0, longest: 0 };
  }

  const normalizedAndUnique = Array.from(
    new Map(
      periodStarts
        .map((date) => getPeriodStart(date, frequency))
        .map((date) => [date.getTime(), date]),
    ).values(),
  ).sort((a, b) => a.getTime() - b.getTime());

  let longest = 1;
  let run = 1;

  for (let index = 1; index < normalizedAndUnique.length; index += 1) {
    const current = normalizedAndUnique[index];
    const previous = normalizedAndUnique[index - 1];

    if (isConsecutivePeriod(current, previous, frequency)) {
      run += 1;
    } else {
      run = 1;
    }

    longest = Math.max(longest, run);
  }

  const periodSet = new Set(normalizedAndUnique.map((date) => date.getTime()));
  let expected = getPeriodStart(referenceDate, frequency);
  let current = 0;

  while (periodSet.has(expected.getTime())) {
    current += 1;
    expected = getPreviousPeriodStart(expected, frequency);
  }

  return { current, longest };
}

export function activeDaysInWindow(dates: Date[], days: number): number {
  const cutoff = subDays(new Date(), days - 1);
  const uniqueDays = new Set(
    dates.filter((date) => date >= cutoff).map((date) => dayKey(date)),
  );

  return uniqueDays.size;
}
