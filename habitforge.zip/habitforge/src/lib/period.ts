import type { Frequency } from "@/lib/contracts";
import {
  format,
  isSameDay,
  isSameWeek,
  startOfDay,
  startOfISOWeek,
  subDays,
  subWeeks,
} from "date-fns";

export const DAILY_KEY_FORMAT = "yyyy-MM-dd";
export const WEEKLY_KEY_FORMAT = "RRRR-'W'II";

export function getPeriodStart(date: Date, frequency: Frequency): Date {
  if (frequency === "WEEKLY") {
    return startOfISOWeek(date);
  }

  return startOfDay(date);
}

export function getPeriodKey(date: Date, frequency: Frequency): string {
  return format(getPeriodStart(date, frequency),
    frequency === "WEEKLY" ? WEEKLY_KEY_FORMAT : DAILY_KEY_FORMAT);
}

export function isConsecutivePeriod(
  current: Date,
  previous: Date,
  frequency: Frequency,
): boolean {
  const normalizedCurrent = getPeriodStart(current, frequency);
  const normalizedPrevious = getPeriodStart(previous, frequency);

  if (frequency === "WEEKLY") {
    return isSameWeek(subWeeks(normalizedCurrent, 1), normalizedPrevious, {
      weekStartsOn: 1,
    });
  }

  return isSameDay(subDays(normalizedCurrent, 1), normalizedPrevious);
}

export function getPreviousPeriodStart(date: Date, frequency: Frequency): Date {
  const start = getPeriodStart(date, frequency);
  return frequency === "WEEKLY" ? subWeeks(start, 1) : subDays(start, 1);
}

export function dayKey(date: Date): string {
  return format(startOfDay(date), DAILY_KEY_FORMAT);
}
