import type { Frequency, SubscriptionTier } from "@/lib/contracts";
import {
  addDays,
  eachDayOfInterval,
  endOfDay,
  format,
  startOfDay,
  startOfISOWeek,
  subDays,
} from "date-fns";
import {
  ACHIEVEMENTS,
  activeDaysInWindow,
  calculateLevel,
  getStreakStats,
  pointsForCompletion,
} from "@/lib/gamification";
import { dayKey, getPeriodKey, getPeriodStart } from "@/lib/period";
import { prisma } from "@/lib/prisma";

const DEFAULT_USER_NAME = "Trailblazer";

export type HabitDashboardItem = {
  id: string;
  name: string;
  description: string | null;
  color: string;
  frequency: Frequency;
  targetCount: number;
  periodProgress: number;
  isCompletedThisPeriod: boolean;
  currentStreak: number;
  longestStreak: number;
  totalMilestones: number;
  lastLoggedAt: string | null;
};

export type DashboardPayload = {
  user: {
    id: string;
    displayName: string;
    subscriptionTier: SubscriptionTier;
    shareProgress: boolean;
    points: number;
    level: number;
    currentStreak: number;
    longestStreak: number;
    totalCompletions: number;
  };
  summary: {
    activeHabits: number;
    completionRateThisWeek: number;
    achievementsUnlocked: number;
  };
  habits: HabitDashboardItem[];
  achievements: {
    key: string;
    title: string;
    description: string;
    unlockedAt: string;
  }[];
  charts: {
    labels: string[];
    completionSeries: number[];
    pointSeries: number[];
  };
  leaderboard: {
    id: string;
    displayName: string;
    level: number;
    points: number;
  }[];
};

export type PremiumAnalyticsPayload = {
  consistencyByHabit: {
    habitId: string;
    habitName: string;
    frequency: Frequency;
    score: number;
  }[];
  bestDayOfWeek: string;
  strongestHabit: string;
  totalPointsLast30Days: number;
};

export type ResourceItem = {
  title: string;
  type: "guide" | "template" | "challenge";
  duration: string;
  description: string;
};

export const PREMIUM_RESOURCE_LIBRARY: ResourceItem[] = [
  {
    title: "Atomic Habit Blueprint",
    type: "guide",
    duration: "15 min",
    description:
      "A practical framework for shrinking habits into tiny, repeatable actions.",
  },
  {
    title: "Weekly Reflection Template",
    type: "template",
    duration: "10 min",
    description:
      "Review wins, misses, and next-step habit adjustments every Sunday.",
  },
  {
    title: "21-Day Consistency Challenge",
    type: "challenge",
    duration: "21 days",
    description:
      "A focused challenge to stabilize one keystone habit and lock in momentum.",
  },
  {
    title: "Identity-Based Habit Playbook",
    type: "guide",
    duration: "12 min",
    description:
      "Move from outcome goals to identity goals for long-term behavior change.",
  },
];

type PeriodAggregate = {
  periodKey: string;
  periodStart: Date;
  amount: number;
  lastLoggedAt: Date;
};

type CompletionRecord = {
  periodKey: string;
  periodStart: Date;
  amount: number;
  loggedAt: Date;
};

type HabitRecord = {
  id: string;
  name: string;
  description: string | null;
  color: string;
  frequency: Frequency;
  targetCount: number;
  completions: CompletionRecord[];
};

function aggregateCompletionsByPeriod(
  completions: CompletionRecord[],
): PeriodAggregate[] {
  const bucket = new Map<string, PeriodAggregate>();

  for (const completion of completions) {
    const current = bucket.get(completion.periodKey);

    if (!current) {
      bucket.set(completion.periodKey, {
        periodKey: completion.periodKey,
        periodStart: completion.periodStart,
        amount: completion.amount,
        lastLoggedAt: completion.loggedAt,
      });
      continue;
    }

    current.amount += completion.amount;
    if (completion.loggedAt > current.lastLoggedAt) {
      current.lastLoggedAt = completion.loggedAt;
    }
  }

  return Array.from(bucket.values()).sort(
    (a, b) => a.periodStart.getTime() - b.periodStart.getTime(),
  );
}

function getHabitMetrics(habit: HabitRecord): HabitDashboardItem {
  const now = new Date();
  const aggregates = aggregateCompletionsByPeriod(habit.completions);
  const currentPeriodKey = getPeriodKey(now, habit.frequency);
  const currentPeriod = aggregates.find((entry) => entry.periodKey === currentPeriodKey);
  const completedPeriods = aggregates.filter(
    (entry) => entry.amount >= habit.targetCount,
  );

  const streakStats = getStreakStats(
    completedPeriods.map((entry) => entry.periodStart),
    habit.frequency,
    now,
  );

  const lastLoggedAt =
    habit.completions.length > 0
      ? habit.completions.reduce((latest, completion) =>
          completion.loggedAt > latest ? completion.loggedAt : latest,
        habit.completions[0].loggedAt)
      : null;

  return {
    id: habit.id,
    name: habit.name,
    description: habit.description,
    color: habit.color,
    frequency: habit.frequency,
    targetCount: habit.targetCount,
    periodProgress: currentPeriod?.amount ?? 0,
    isCompletedThisPeriod: (currentPeriod?.amount ?? 0) >= habit.targetCount,
    currentStreak: streakStats.current,
    longestStreak: streakStats.longest,
    totalMilestones: completedPeriods.length,
    lastLoggedAt: lastLoggedAt ? lastLoggedAt.toISOString() : null,
  };
}

function calculateWeeklyCompletionRate(
  habits: HabitRecord[],
): number {
  if (habits.length === 0) {
    return 0;
  }

  const weekStart = startOfISOWeek(new Date());
  const weekEnd = endOfDay(addDays(weekStart, 6));
  const weeklyKey = getPeriodKey(weekStart, "WEEKLY");

  let expected = 0;
  let actual = 0;

  for (const habit of habits) {
    if (habit.frequency === "DAILY") {
      expected += 7 * habit.targetCount;
      actual += Math.min(
        habit.completions
          .filter(
            (completion) =>
              completion.loggedAt >= weekStart && completion.loggedAt <= weekEnd,
          )
          .reduce((total, completion) => total + completion.amount, 0),
        7 * habit.targetCount,
      );
      continue;
    }

    expected += habit.targetCount;

    actual += Math.min(
      habit.completions
        .filter((completion) => completion.periodKey === weeklyKey)
        .reduce((total, completion) => total + completion.amount, 0),
      habit.targetCount,
    );
  }

  return expected === 0 ? 0 : Math.round((actual / expected) * 100);
}

export async function ensureDemoUser() {
  const existingUsers = await prisma.user.findMany({
    take: 1,
    orderBy: { createdAt: "asc" },
  });

  if (existingUsers.length > 0) {
    return existingUsers[0];
  }

  const user = await prisma.user.create({
    data: {
      displayName: DEFAULT_USER_NAME,
    },
  });

  await prisma.habit.createMany({
    data: [
      {
        userId: user.id,
        name: "Drink 8 glasses of water",
        description: "Hydration keeps energy and focus stable.",
        frequency: "DAILY",
        targetCount: 1,
        color: "#1A936F",
      },
      {
        userId: user.id,
        name: "Read 10 pages",
        description: "Small daily reading builds long-term learning.",
        frequency: "DAILY",
        targetCount: 1,
        color: "#CA6702",
      },
      {
        userId: user.id,
        name: "Workout sessions",
        description: "Aim for 3 sessions every week.",
        frequency: "WEEKLY",
        targetCount: 3,
        color: "#0A9396",
      },
    ],
  });

  return user;
}

export async function refreshUserGamification(userId: string) {
  const [user, habitsCount, completions, currentAchievements] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId } }),
    prisma.habit.count({ where: { userId, isArchived: false } }),
    prisma.completion.findMany({
      where: { userId },
      select: {
        amount: true,
        loggedAt: true,
      },
    }),
    prisma.userAchievement.findMany({ where: { userId } }),
  ]);

  if (!user) {
    return [];
  }

  const totalCompletions = completions.reduce(
    (total, completion) => total + completion.amount,
    0,
  );

  const activityDates = completions.map((completion) => completion.loggedAt);
  const streakStats = getStreakStats(activityDates, "DAILY");
  const daysActiveLast7 = activeDaysInWindow(activityDates, 7);

  const level = calculateLevel(user.points);

  await prisma.user.update({
    where: { id: userId },
    data: {
      level,
      totalCompletions,
      currentStreak: streakStats.current,
      longestStreak: streakStats.longest,
    },
  });

  const existingKeys = new Set(currentAchievements.map((achievement) => achievement.key));

  const newlyUnlocked = ACHIEVEMENTS.filter(
    (achievement) =>
      !existingKeys.has(achievement.key) &&
      achievement.predicate({
        points: user.points,
        totalCompletions,
        longestStreak: streakStats.longest,
        habitCount: habitsCount,
        shareProgress: user.shareProgress,
        daysActiveLast7,
        subscriptionTier: user.subscriptionTier,
      }),
  );

  if (newlyUnlocked.length > 0) {
    await Promise.all(
      newlyUnlocked.map((achievement) =>
        prisma.userAchievement.upsert({
          where: {
            userId_key: {
              userId,
              key: achievement.key,
            },
          },
          update: {},
          create: {
            userId,
            key: achievement.key,
            title: achievement.title,
            description: achievement.description,
          },
        }),
      ),
    );
  }

  return newlyUnlocked;
}

export async function buildDashboard(userId: string): Promise<DashboardPayload | null> {
  const [user, habits, achievements, recentCompletions, recentPointEvents, leaderboard] =
    await Promise.all([
      prisma.user.findUnique({ where: { id: userId } }),
      prisma.habit.findMany({
        where: {
          userId,
          isArchived: false,
        },
        include: {
          completions: {
            orderBy: { loggedAt: "desc" },
          },
        },
        orderBy: { createdAt: "asc" },
      }),
      prisma.userAchievement.findMany({
        where: { userId },
        orderBy: { unlockedAt: "desc" },
      }),
      prisma.completion.findMany({
        where: {
          userId,
          loggedAt: {
            gte: subDays(startOfDay(new Date()), 27),
          },
        },
        select: {
          amount: true,
          loggedAt: true,
        },
      }),
      prisma.pointEvent.findMany({
        where: {
          userId,
          createdAt: {
            gte: subDays(startOfDay(new Date()), 27),
          },
        },
        select: {
          points: true,
          createdAt: true,
        },
      }),
      prisma.user.findMany({
        where: { shareProgress: true },
        orderBy: [{ points: "desc" }, { level: "desc" }],
        take: 10,
        select: {
          id: true,
          displayName: true,
          level: true,
          points: true,
        },
      }),
    ]);

  if (!user) {
    return null;
  }

  const habitCards = habits.map(getHabitMetrics);
  const completionRateThisWeek = calculateWeeklyCompletionRate(habits);

  const dayRange = eachDayOfInterval({
    start: subDays(startOfDay(new Date()), 27),
    end: startOfDay(new Date()),
  });

  const completionMap = new Map<string, number>();
  for (const item of recentCompletions) {
    const key = dayKey(item.loggedAt);
    completionMap.set(key, (completionMap.get(key) ?? 0) + item.amount);
  }

  const pointMap = new Map<string, number>();
  for (const item of recentPointEvents) {
    const key = dayKey(item.createdAt);
    pointMap.set(key, (pointMap.get(key) ?? 0) + item.points);
  }

  const labels = dayRange.map((day) => format(day, "MMM d"));
  const completionSeries = dayRange.map((day) => completionMap.get(dayKey(day)) ?? 0);
  const pointSeries = dayRange.map((day) => pointMap.get(dayKey(day)) ?? 0);

  return {
    user: {
      id: user.id,
      displayName: user.displayName,
      subscriptionTier: user.subscriptionTier,
      shareProgress: user.shareProgress,
      points: user.points,
      level: user.level,
      currentStreak: user.currentStreak,
      longestStreak: user.longestStreak,
      totalCompletions: user.totalCompletions,
    },
    summary: {
      activeHabits: habits.length,
      completionRateThisWeek,
      achievementsUnlocked: achievements.length,
    },
    habits: habitCards,
    achievements: achievements.map((achievement) => ({
      key: achievement.key,
      title: achievement.title,
      description: achievement.description,
      unlockedAt: achievement.unlockedAt.toISOString(),
    })),
    charts: {
      labels,
      completionSeries,
      pointSeries,
    },
    leaderboard,
  };
}

export async function awardPointsForCompletion(params: {
  userId: string;
  habitId: string;
  streak: number;
  reason: string;
}) {
  const earnedPoints = pointsForCompletion(params.streak);

  await prisma.$transaction([
    prisma.user.update({
      where: { id: params.userId },
      data: {
        points: {
          increment: earnedPoints,
        },
      },
    }),
    prisma.pointEvent.create({
      data: {
        userId: params.userId,
        habitId: params.habitId,
        points: earnedPoints,
        reason: params.reason,
      },
    }),
  ]);

  return earnedPoints;
}

function clampPercentage(value: number): number {
  if (Number.isNaN(value)) {
    return 0;
  }

  if (value < 0) {
    return 0;
  }

  if (value > 100) {
    return 100;
  }

  return Math.round(value);
}

export async function buildPremiumAnalytics(
  userId: string,
): Promise<PremiumAnalyticsPayload | null> {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || user.subscriptionTier !== "PREMIUM") {
    return null;
  }

  const windowStart = subDays(startOfDay(new Date()), 29);
  const habits = await prisma.habit.findMany({
    where: { userId, isArchived: false },
    include: {
      completions: {
        where: {
          loggedAt: { gte: windowStart },
        },
      },
    },
  });

  const consistencyByHabit = habits.map((habit) => {
    const actual = habit.completions.reduce(
      (total, completion) => total + completion.amount,
      0,
    );
    const expected =
      habit.frequency === "DAILY"
        ? 30 * habit.targetCount
        : 5 * habit.targetCount;

    const score = clampPercentage((Math.min(actual, expected) / expected) * 100);

    return {
      habitId: habit.id,
      habitName: habit.name,
      frequency: habit.frequency,
      score,
    };
  });

  consistencyByHabit.sort((a, b) => b.score - a.score);

  const recentCompletions = await prisma.completion.findMany({
    where: {
      userId,
      loggedAt: {
        gte: windowStart,
      },
    },
    select: {
      loggedAt: true,
    },
  });

  const weekDayCounter = new Array<number>(7).fill(0);
  for (const completion of recentCompletions) {
    weekDayCounter[completion.loggedAt.getDay()] += 1;
  }

  const bestDayIndex = weekDayCounter.reduce(
    (maxIndex, value, index, arr) => (value > arr[maxIndex] ? index : maxIndex),
    0,
  );

  const weekDayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  const pointsLast30Days = await prisma.pointEvent.aggregate({
    where: {
      userId,
      createdAt: {
        gte: windowStart,
      },
    },
    _sum: {
      points: true,
    },
  });

  return {
    consistencyByHabit,
    bestDayOfWeek: weekDayNames[bestDayIndex],
    strongestHabit: consistencyByHabit[0]?.habitName ?? "No habit data yet",
    totalPointsLast30Days: pointsLast30Days._sum.points ?? 0,
  };
}

export async function exportUserCsv(userId: string): Promise<string | null> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      habits: {
        where: { isArchived: false },
        include: {
          completions: {
            orderBy: { loggedAt: "desc" },
          },
        },
      },
    },
  });

  if (!user || user.subscriptionTier !== "PREMIUM") {
    return null;
  }

  const rows = [
    [
      "habit_name",
      "habit_frequency",
      "target_count",
      "period_key",
      "period_start",
      "amount",
      "logged_at",
    ],
  ];

  for (const habit of user.habits) {
    for (const completion of habit.completions) {
      rows.push([
        habit.name,
        habit.frequency,
        String(habit.targetCount),
        completion.periodKey,
        completion.periodStart.toISOString(),
        String(completion.amount),
        completion.loggedAt.toISOString(),
      ]);
    }
  }

  return rows
    .map((row) => row.map((cell) => `"${cell.replaceAll('"', '""')}"`).join(","))
    .join("\n");
}

export async function requireUser(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  return user;
}

export function getPremiumResources() {
  return PREMIUM_RESOURCE_LIBRARY;
}

export function getCompletionPeriodInfo(
  habit: Pick<HabitRecord, "frequency">,
  loggedAt: Date,
) {
  const periodStart = getPeriodStart(loggedAt, habit.frequency);
  const periodKey = getPeriodKey(loggedAt, habit.frequency);

  return {
    periodStart,
    periodKey,
  };
}
