import { FREQUENCIES, SUBSCRIPTION_TIERS } from "@/lib/contracts";
import { z } from "zod";

export const createUserSchema = z.object({
  displayName: z.string().trim().min(2).max(40),
  email: z.string().email().optional(),
});

export const createHabitSchema = z.object({
  name: z.string().trim().min(2).max(60),
  description: z.string().trim().max(200).optional(),
  frequency: z.enum(FREQUENCIES),
  targetCount: z.number().int().min(1).max(10),
  color: z
    .string()
    .regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/)
    .optional(),
});

export const updateHabitSchema = z.object({
  name: z.string().trim().min(2).max(60).optional(),
  description: z.string().trim().max(200).nullable().optional(),
  frequency: z.enum(FREQUENCIES).optional(),
  targetCount: z.number().int().min(1).max(10).optional(),
  color: z
    .string()
    .regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/)
    .optional(),
  isArchived: z.boolean().optional(),
});

export const completionSchema = z.object({
  amount: z.number().int().min(1).max(10).default(1),
  loggedAt: z.string().datetime().optional(),
});

export const subscriptionSchema = z.object({
  tier: z.enum(SUBSCRIPTION_TIERS),
});

export const shareSchema = z.object({
  shareProgress: z.boolean(),
});
