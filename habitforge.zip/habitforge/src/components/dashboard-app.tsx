"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  type ChartOptions,
  Filler,
  Legend,
  LineElement,
  LinearScale,
  PointElement,
  Tooltip,
} from "chart.js";
import { Bar, Line } from "react-chartjs-2";
import {
  Activity,
  Award,
  Crown,
  Flame,
  Gem,
  Goal,
  Loader2,
  Plus,
  Rocket,
  Share2,
  Sparkles,
  Trophy,
} from "lucide-react";
import { formatDistanceToNowStrict } from "date-fns";
import type {
  DashboardData,
  PremiumAnalyticsData,
  PremiumResource,
  UserSummary,
} from "@/lib/contracts";
import { cn } from "@/lib/utils";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Tooltip,
  Legend,
  Filler,
);

const habitColors = [
  "#1A936F",
  "#0A9396",
  "#CA6702",
  "#005F73",
  "#EE9B00",
  "#9B2226",
];

type HabitFormState = {
  name: string;
  description: string;
  frequency: "DAILY" | "WEEKLY";
  targetCount: number;
  color: string;
};

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...init?.headers,
    },
    cache: "no-store",
  });

  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(payload?.error ?? "Request failed");
  }

  return payload as T;
}

export function DashboardApp() {
  const [users, setUsers] = useState<UserSummary[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [premiumAnalytics, setPremiumAnalytics] = useState<PremiumAnalyticsData | null>(
    null,
  );
  const [resources, setResources] = useState<PremiumResource[]>([]);

  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [newProfileName, setNewProfileName] = useState("");
  const [habitForm, setHabitForm] = useState<HabitFormState>({
    name: "",
    description: "",
    frequency: "DAILY",
    targetCount: 1,
    color: habitColors[0],
  });

  const isPremium = dashboard?.user.subscriptionTier === "PREMIUM";
  const isBusy = loading || Boolean(actionLoading);

  const loadUsers = useCallback(async () => {
    const data = await fetchJson<{ users: UserSummary[] }>("/api/users");
    setUsers(data.users);

    if (data.users.length > 0) {
      setSelectedUserId((previous) =>
        previous && data.users.some((user) => user.id === previous)
          ? previous
          : data.users[0].id,
      );
    }
  }, []);

  const loadDashboard = useCallback(async (userId: string) => {
    const data = await fetchJson<DashboardData>(`/api/users/${userId}/dashboard`);
    setDashboard(data);
  }, []);

  const loadPremium = useCallback(async (userId: string) => {
    const [analyticsResponse, resourcesResponse] = await Promise.all([
      fetch(`/api/users/${userId}/premium/analytics`, { cache: "no-store" }),
      fetch(`/api/users/${userId}/premium/resources`, { cache: "no-store" }),
    ]);

    if (analyticsResponse.ok) {
      const analytics = (await analyticsResponse.json()) as PremiumAnalyticsData;
      setPremiumAnalytics(analytics);
    } else {
      setPremiumAnalytics(null);
    }

    if (resourcesResponse.ok) {
      const payload = (await resourcesResponse.json()) as { resources: PremiumResource[] };
      setResources(payload.resources);
    } else {
      setResources([]);
    }
  }, []);

  const refreshAll = useCallback(
    async (userId: string) => {
      await loadDashboard(userId);
      await loadUsers();
      await loadPremium(userId);
    },
    [loadDashboard, loadUsers, loadPremium],
  );

  useEffect(() => {
    const bootstrap = async () => {
      try {
        setLoading(true);
        await loadUsers();
      } catch (loadError) {
        setError(loadError instanceof Error ? loadError.message : "Failed to load users");
      } finally {
        setLoading(false);
      }
    };

    void bootstrap();
  }, [loadUsers]);

  useEffect(() => {
    if (!selectedUserId) {
      return;
    }

    const load = async () => {
      try {
        setLoading(true);
        setError(null);
        await refreshAll(selectedUserId);
      } catch (loadError) {
        setError(loadError instanceof Error ? loadError.message : "Failed to load dashboard");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [refreshAll, selectedUserId]);

  async function runAction(action: string, fn: () => Promise<void>) {
    try {
      setActionLoading(action);
      setError(null);
      await fn();
    } catch (actionError) {
      setError(actionError instanceof Error ? actionError.message : "Something went wrong");
    } finally {
      setActionLoading(null);
    }
  }

  async function handleCreateProfile(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!newProfileName.trim()) {
      setError("Enter a profile name.");
      return;
    }

    await runAction("create-profile", async () => {
      const payload = await fetchJson<{ user: UserSummary }>("/api/users", {
        method: "POST",
        body: JSON.stringify({
          displayName: newProfileName.trim(),
        }),
      });

      setNewProfileName("");
      setSelectedUserId(payload.user.id);
      setNotice(`Profile created for ${payload.user.displayName}`);
      await refreshAll(payload.user.id);
    });
  }

  async function handleCreateHabit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!selectedUserId) {
      return;
    }

    await runAction("create-habit", async () => {
      await fetchJson(`/api/users/${selectedUserId}/habits`, {
        method: "POST",
        body: JSON.stringify(habitForm),
      });

      setHabitForm({
        name: "",
        description: "",
        frequency: "DAILY",
        targetCount: 1,
        color: habitColors[Math.floor(Math.random() * habitColors.length)],
      });

      setNotice("Habit added to your forge.");
      await refreshAll(selectedUserId);
    });
  }

  async function handleCompleteHabit(habitId: string) {
    if (!selectedUserId) {
      return;
    }

    await runAction(`complete-${habitId}`, async () => {
      const payload = await fetchJson<{ pointsEarned: number; milestoneHit: boolean }>(
        `/api/users/${selectedUserId}/habits/${habitId}/complete`,
        {
          method: "POST",
          body: JSON.stringify({ amount: 1 }),
        },
      );

      if (payload.milestoneHit && payload.pointsEarned > 0) {
        setNotice(`Milestone unlocked: +${payload.pointsEarned} XP`);
      } else {
        setNotice("Progress logged.");
      }

      await refreshAll(selectedUserId);
    });
  }

  async function handleArchiveHabit(habitId: string) {
    if (!selectedUserId) {
      return;
    }

    await runAction(`archive-${habitId}`, async () => {
      await fetchJson(`/api/users/${selectedUserId}/habits/${habitId}`, {
        method: "DELETE",
      });

      setNotice("Habit archived.");
      await refreshAll(selectedUserId);
    });
  }

  async function handleTogglePremium() {
    if (!selectedUserId || !dashboard) {
      return;
    }

    const nextTier = dashboard.user.subscriptionTier === "PREMIUM" ? "FREE" : "PREMIUM";

    await runAction("toggle-premium", async () => {
      await fetchJson(`/api/users/${selectedUserId}/subscription`, {
        method: "PATCH",
        body: JSON.stringify({ tier: nextTier }),
      });

      setNotice(
        nextTier === "PREMIUM"
          ? "Premium unlocked: analytics, export, and resources are live."
          : "Switched back to free tier.",
      );

      await refreshAll(selectedUserId);
    });
  }

  async function handleToggleShare() {
    if (!selectedUserId || !dashboard) {
      return;
    }

    await runAction("toggle-share", async () => {
      await fetchJson(`/api/users/${selectedUserId}/share`, {
        method: "PATCH",
        body: JSON.stringify({ shareProgress: !dashboard.user.shareProgress }),
      });

      setNotice(
        dashboard.user.shareProgress
          ? "Sharing disabled."
          : "Sharing enabled. You are now on the leaderboard.",
      );

      await refreshAll(selectedUserId);
    });
  }

  async function handleExportCsv() {
    if (!selectedUserId) {
      return;
    }

    await runAction("export-csv", async () => {
      const response = await fetch(`/api/users/${selectedUserId}/premium/export`, {
        method: "GET",
      });

      if (!response.ok) {
        const payload = await response.json().catch(() => null);
        throw new Error(payload?.error ?? "Unable to export data");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `habitforge-${selectedUserId}.csv`;
      anchor.click();
      URL.revokeObjectURL(url);

      setNotice("CSV export downloaded.");
    });
  }

  const charts = useMemo(() => {
    if (!dashboard) {
      return null;
    }

    const lineData = {
      labels: dashboard.charts.labels,
      datasets: [
        {
          label: "Completions",
          data: dashboard.charts.completionSeries,
          borderColor: "#1A936F",
          backgroundColor: "rgba(26, 147, 111, 0.18)",
          fill: true,
          tension: 0.35,
          pointRadius: 0,
          pointHitRadius: 8,
        },
      ],
    };

    const barData = {
      labels: dashboard.charts.labels,
      datasets: [
        {
          label: "XP Earned",
          data: dashboard.charts.pointSeries,
          backgroundColor: "#CA6702",
          borderRadius: 8,
        },
      ],
    };

    return { lineData, barData };
  }, [dashboard]);

  const baseChartOptions = useMemo(
    () => ({
      responsive: true,
      maintainAspectRatio: false,
      animation: false as const,
      resizeDelay: 150,
      normalized: true,
      plugins: {
        legend: {
          labels: {
            color: "#d6e5ec",
          },
        },
      },
      scales: {
        x: {
          ticks: {
            color: "#8aa0ad",
            maxRotation: 0,
          },
          grid: { color: "rgba(122, 146, 162, 0.16)" },
        },
        y: {
          ticks: { color: "#8aa0ad" },
          grid: { color: "rgba(122, 146, 162, 0.16)" },
        },
      },
    }),
    [],
  );

  const levelProgress = useMemo(() => {
    if (!dashboard) {
      return { progress: 0, nextLevelIn: 0 };
    }

    const currentLevelFloor = 120 * (dashboard.user.level - 1) ** 2;
    const nextLevelFloor = 120 * dashboard.user.level ** 2;
    const levelSpan = Math.max(nextLevelFloor - currentLevelFloor, 1);
    const progress = Math.min(
      100,
      Math.max(0, ((dashboard.user.points - currentLevelFloor) / levelSpan) * 100),
    );

    return {
      progress,
      nextLevelIn: Math.max(nextLevelFloor - dashboard.user.points, 0),
    };
  }, [dashboard]);

  if (loading && !dashboard) {
    return <AppLoader label="Charging your habit forge..." />;
  }

  return (
    <main className="relative min-h-screen px-4 py-8 sm:px-8 lg:px-12">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_12%,rgba(26,147,111,0.18),transparent_42%),linear-gradient(150deg,#04161f_0%,#082633_48%,#0a1f2a_100%)]" />
      {isBusy ? (
        <div className="pointer-events-none fixed inset-0 z-50 bg-[#071822]/35 backdrop-blur-[1px]">
          <div className="absolute right-4 top-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-slate-900/80 px-3 py-1.5 text-xs font-medium text-slate-200">
            <Loader2 size={14} className="animate-spin" />
            Syncing your progress...
          </div>
        </div>
      ) : null}

      <section className="mx-auto flex w-full max-w-7xl flex-col gap-6">
        <header className="rounded-3xl border border-white/10 bg-gradient-to-br from-white/10 to-white/4 p-6 shadow-[0_18px_45px_rgba(0,0,0,0.18)] sm:p-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-emerald-200/80">
                <Sparkles size={13} />
                HabitForge
              </p>
              <h1 className="mt-2 text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                Build habits that actually stick
              </h1>
              <p className="mt-3 max-w-2xl text-sm text-slate-200/90 sm:text-base">
                Track daily and weekly routines, earn XP through consistency, unlock badges,
                and turn discipline into a game loop you enjoy.
              </p>
            </div>
            <div className="grid gap-3 rounded-2xl border border-white/15 bg-black/20 p-4 sm:min-w-72">
              <label className="text-xs uppercase tracking-[0.2em] text-slate-300">Active Profile</label>
              <select
                value={selectedUserId}
                onChange={(event) => setSelectedUserId(event.target.value)}
                className="rounded-xl border border-white/20 bg-slate-900/70 px-3 py-2 text-sm text-white outline-none"
              >
                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.displayName}
                  </option>
                ))}
              </select>
              <form onSubmit={handleCreateProfile} className="flex gap-2">
                <input
                  value={newProfileName}
                  onChange={(event) => setNewProfileName(event.target.value)}
                  placeholder="New profile name"
                  className="w-full rounded-xl border border-white/20 bg-slate-900/70 px-3 py-2 text-sm text-white placeholder:text-slate-400"
                />
                <button
                  type="submit"
                  disabled={actionLoading === "create-profile"}
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-3 py-2 text-sm font-semibold text-slate-900 transition hover:bg-emerald-300 disabled:opacity-60"
                >
                  {actionLoading === "create-profile" ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : null}
                  Add
                </button>
              </form>
            </div>
          </div>
        </header>

        {error ? (
          <div className="rounded-2xl border border-rose-300/40 bg-rose-500/15 px-4 py-3 text-sm text-rose-100">
            {error}
          </div>
        ) : null}

        {notice ? (
          <div className="rounded-2xl border border-emerald-300/40 bg-emerald-500/15 px-4 py-3 text-sm text-emerald-100">
            {notice}
          </div>
        ) : null}

        {dashboard ? (
          <>
            <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard
                icon={<Rocket size={18} />}
                label="Level"
                value={`Lv. ${dashboard.user.level}`}
                subtitle={`${dashboard.user.points} XP total`}
              />
              <StatCard
                icon={<Flame size={18} />}
                label="Current Streak"
                value={`${dashboard.user.currentStreak} days`}
                subtitle={`Best: ${dashboard.user.longestStreak} days`}
              />
              <StatCard
                icon={<Goal size={18} />}
                label="Active Habits"
                value={`${dashboard.summary.activeHabits}`}
                subtitle={`${dashboard.summary.completionRateThisWeek}% weekly completion`}
              />
              <StatCard
                icon={<Award size={18} />}
                label="Achievements"
                value={`${dashboard.summary.achievementsUnlocked}`}
                subtitle={`${dashboard.user.totalCompletions} completions logged`}
              />
            </section>

            <section className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
              <div className="rounded-3xl border border-white/12 bg-slate-950/55 p-6">
                <div className="flex items-center justify-between gap-3">
                  <h2 className="text-xl font-semibold text-white">Progress Engine</h2>
                  <button
                    type="button"
                    onClick={handleTogglePremium}
                    disabled={actionLoading === "toggle-premium"}
                    className={cn(
                      "rounded-xl px-3 py-2 text-sm font-medium transition",
                      isPremium
                        ? "bg-amber-300 text-slate-900 hover:bg-amber-200"
                        : "bg-emerald-400 text-slate-900 hover:bg-emerald-300",
                    )}
                  >
                    {isPremium ? "Switch to Free" : "Upgrade to Premium"}
                  </button>
                </div>

                <p className="mt-2 text-sm text-slate-300">
                  {dashboard.user.displayName}, you need {levelProgress.nextLevelIn} XP to reach
                  the next level.
                </p>
                <div className="mt-4 h-3 overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300"
                    style={{ width: `${levelProgress.progress}%` }}
                  />
                </div>

                <div className="mt-5 flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={handleToggleShare}
                    disabled={actionLoading === "toggle-share"}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium transition",
                      dashboard.user.shareProgress
                        ? "border border-emerald-300/50 bg-emerald-400/20 text-emerald-100"
                        : "border border-slate-600 bg-slate-800 text-slate-100 hover:bg-slate-700",
                    )}
                  >
                    <Share2 size={14} />
                    {dashboard.user.shareProgress ? "Sharing enabled" : "Enable sharing"}
                  </button>

                  {isPremium ? (
                    <button
                      type="button"
                      onClick={handleExportCsv}
                      disabled={actionLoading === "export-csv"}
                      className="rounded-xl border border-amber-200/40 bg-amber-300/20 px-3 py-2 text-sm font-medium text-amber-100 transition hover:bg-amber-300/30"
                    >
                      Export CSV
                    </button>
                  ) : null}
                </div>
              </div>

              <form
                onSubmit={handleCreateHabit}
                className="rounded-3xl border border-white/12 bg-slate-950/55 p-6"
              >
                <h2 className="text-xl font-semibold text-white">Forge New Habit</h2>
                <div className="mt-4 grid gap-3">
                  <input
                    value={habitForm.name}
                    onChange={(event) =>
                      setHabitForm((current) => ({ ...current, name: event.target.value }))
                    }
                    required
                    placeholder="Habit name"
                    className="rounded-xl border border-white/15 bg-slate-900/70 px-3 py-2 text-sm text-white placeholder:text-slate-400"
                  />
                  <textarea
                    value={habitForm.description}
                    onChange={(event) =>
                      setHabitForm((current) => ({ ...current, description: event.target.value }))
                    }
                    rows={2}
                    placeholder="Optional description"
                    className="rounded-xl border border-white/15 bg-slate-900/70 px-3 py-2 text-sm text-white placeholder:text-slate-400"
                  />
                  <div className="grid gap-3 sm:grid-cols-3">
                    <select
                      value={habitForm.frequency}
                      onChange={(event) =>
                        setHabitForm((current) => ({
                          ...current,
                          frequency: event.target.value as HabitFormState["frequency"],
                        }))
                      }
                      className="rounded-xl border border-white/15 bg-slate-900/70 px-3 py-2 text-sm text-white"
                    >
                      <option value="DAILY">Daily</option>
                      <option value="WEEKLY">Weekly</option>
                    </select>
                    <input
                      type="number"
                      min={1}
                      max={10}
                      value={habitForm.targetCount}
                      onChange={(event) =>
                        setHabitForm((current) => ({
                          ...current,
                          targetCount: Number(event.target.value),
                        }))
                      }
                      className="rounded-xl border border-white/15 bg-slate-900/70 px-3 py-2 text-sm text-white"
                    />
                    <input
                      type="color"
                      value={habitForm.color}
                      onChange={(event) =>
                        setHabitForm((current) => ({ ...current, color: event.target.value }))
                      }
                      className="h-10 w-full rounded-xl border border-white/15 bg-slate-900/70 p-1"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={actionLoading === "create-habit"}
                  className="mt-4 inline-flex items-center gap-2 rounded-xl bg-teal-300 px-4 py-2 text-sm font-semibold text-slate-900 transition hover:bg-teal-200 disabled:opacity-60"
                >
                  <Plus size={16} />
                  Add Habit
                </button>
              </form>
            </section>

            <section className="grid gap-6 xl:grid-cols-[1.45fr_1fr]">
              <div className="rounded-3xl border border-white/12 bg-slate-950/55 p-6">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-white">Your Habit Arena</h2>
                  <span className="text-xs uppercase tracking-[0.2em] text-slate-400">
                    complete to earn XP
                  </span>
                </div>
                <div className="grid gap-3">
                  {dashboard.habits.length === 0 ? (
                    <p className="rounded-2xl border border-dashed border-white/20 p-4 text-sm text-slate-300">
                      Create your first habit to start your streak.
                    </p>
                  ) : (
                    dashboard.habits.map((habit) => (
                      <article
                        key={habit.id}
                        className="rounded-2xl border border-white/10 border-l-4 bg-slate-900/70 p-4"
                        style={{ borderLeftColor: habit.color }}
                      >
                        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span
                                className="inline-block h-2.5 w-2.5 rounded-full"
                                style={{ background: habit.color }}
                              />
                              <h3 className="text-base font-semibold text-white">{habit.name}</h3>
                              <span className="rounded-full bg-white/10 px-2 py-0.5 text-xs text-slate-300">
                                {habit.frequency}
                              </span>
                            </div>
                            {habit.description ? (
                              <p className="text-sm text-slate-300">{habit.description}</p>
                            ) : null}
                            <p className="text-xs text-slate-400">
                              Progress {habit.periodProgress}/{habit.targetCount} this period
                              {habit.lastLoggedAt
                                ? ` · last activity ${formatDistanceToNowStrict(
                                    new Date(habit.lastLoggedAt),
                                    { addSuffix: true },
                                  )}`
                                : ""}
                            </p>
                          </div>

                          <div className="flex flex-wrap items-center gap-2">
                            <span className="rounded-full bg-black/30 px-2 py-1 text-xs text-slate-300">
                              {habit.currentStreak} streak
                            </span>
                            <button
                              type="button"
                              onClick={() => void handleCompleteHabit(habit.id)}
                              disabled={actionLoading === `complete-${habit.id}`}
                              className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-400 px-3 py-2 text-xs font-semibold text-slate-900 transition hover:bg-emerald-300 disabled:opacity-60"
                            >
                              {actionLoading === `complete-${habit.id}` ? (
                                <Loader2 size={12} className="animate-spin" />
                              ) : null}
                              {habit.isCompletedThisPeriod ? "Add rep +1" : "Complete +1"}
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleArchiveHabit(habit.id)}
                              disabled={actionLoading === `archive-${habit.id}`}
                              className="inline-flex items-center gap-1.5 rounded-xl border border-white/20 px-3 py-2 text-xs font-medium text-slate-200 transition hover:bg-white/10 disabled:opacity-60"
                            >
                              {actionLoading === `archive-${habit.id}` ? (
                                <Loader2 size={12} className="animate-spin" />
                              ) : null}
                              Archive
                            </button>
                          </div>
                        </div>
                      </article>
                    ))
                  )}
                </div>
              </div>

              <div className="grid gap-6">
                <div className="rounded-3xl border border-white/12 bg-slate-950/55 p-6">
                  <div className="mb-4 flex items-center gap-2 text-white">
                    <Trophy size={18} />
                    <h2 className="text-xl font-semibold">Leaderboard</h2>
                  </div>
                  <div className="space-y-2">
                    {dashboard.leaderboard.length === 0 ? (
                      <p className="text-sm text-slate-300">
                        Enable sharing to appear in competitive mode.
                      </p>
                    ) : (
                      dashboard.leaderboard.map((entry, index) => (
                        <div
                          key={entry.id}
                          className="flex items-center justify-between rounded-xl border border-white/10 bg-slate-900/70 px-3 py-2"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-400">#{index + 1}</span>
                            <span className="text-sm text-white">{entry.displayName}</span>
                          </div>
                          <span className="text-xs text-amber-200">
                            Lv {entry.level} · {entry.points} XP
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="rounded-3xl border border-white/12 bg-slate-950/55 p-6">
                  <div className="mb-4 flex items-center gap-2 text-white">
                    <Award size={18} />
                    <h2 className="text-xl font-semibold">Achievements</h2>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {dashboard.achievements.length === 0 ? (
                      <p className="text-sm text-slate-300">No badges unlocked yet.</p>
                    ) : (
                      dashboard.achievements.map((achievement) => (
                        <div
                          key={achievement.key}
                          className="rounded-xl border border-amber-300/40 bg-amber-400/15 px-3 py-2"
                        >
                          <p className="text-sm font-semibold text-amber-100">{achievement.title}</p>
                          <p className="text-xs text-amber-50/90">{achievement.description}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </section>

            {charts ? (
              <section className="grid gap-6 xl:grid-cols-2">
                <div className="rounded-3xl border border-white/12 bg-slate-950/55 p-6">
                  <div className="mb-4 flex items-center gap-2 text-white">
                    <Activity size={18} />
                    <h2 className="text-xl font-semibold">Completion Trend</h2>
                  </div>
                  <div className="relative h-[280px] w-full">
                    <Line
                      data={charts.lineData}
                      options={baseChartOptions as ChartOptions<"line">}
                    />
                  </div>
                </div>

                <div className="rounded-3xl border border-white/12 bg-slate-950/55 p-6">
                  <div className="mb-4 flex items-center gap-2 text-white">
                    <Gem size={18} />
                    <h2 className="text-xl font-semibold">XP Momentum</h2>
                  </div>
                  <div className="relative h-[280px] w-full">
                    <Bar
                      data={charts.barData}
                      options={baseChartOptions as ChartOptions<"bar">}
                    />
                  </div>
                </div>
              </section>
            ) : null}

            <section className="relative rounded-3xl border border-white/12 bg-slate-950/55 p-6">
              <div className="mb-4 flex items-center gap-2 text-white">
                <Crown size={18} />
                <h2 className="text-xl font-semibold">Premium Intelligence Hub</h2>
              </div>

              {isPremium && premiumAnalytics ? (
                <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
                  <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-4">
                    <p className="text-sm font-semibold text-emerald-200">
                      Strongest habit: {premiumAnalytics.strongestHabit}
                    </p>
                    <p className="mt-1 text-sm text-slate-300">
                      Best day: {premiumAnalytics.bestDayOfWeek} · XP in last 30 days:{" "}
                      {premiumAnalytics.totalPointsLast30Days}
                    </p>
                    <div className="mt-4 space-y-2">
                      {premiumAnalytics.consistencyByHabit.slice(0, 5).map((item) => (
                        <div key={item.habitId}>
                          <div className="flex items-center justify-between text-xs text-slate-300">
                            <span>{item.habitName}</span>
                            <span>{item.score}%</span>
                          </div>
                          <div className="mt-1 h-2 rounded-full bg-slate-800">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-teal-300 to-emerald-400"
                              style={{ width: `${item.score}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid gap-2">
                    {resources.map((resource) => (
                      <div
                        key={resource.title}
                        className="rounded-2xl border border-amber-300/25 bg-amber-400/10 p-3"
                      >
                        <p className="text-sm font-semibold text-amber-100">{resource.title}</p>
                        <p className="text-xs uppercase tracking-[0.12em] text-amber-200/80">
                          {resource.type} · {resource.duration}
                        </p>
                        <p className="mt-1 text-xs text-amber-50/90">{resource.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="rounded-2xl border border-dashed border-amber-300/45 bg-amber-300/12 p-5 text-amber-100">
                  <p className="text-lg font-semibold">Premium is currently locked</p>
                  <p className="mt-1 text-sm text-amber-50/90">
                    Upgrade to unlock advanced analytics, CSV export, and curated habit-building
                    resources.
                  </p>
                  <button
                    type="button"
                    onClick={handleTogglePremium}
                    className="mt-3 rounded-xl bg-amber-300 px-4 py-2 text-sm font-semibold text-slate-900 transition hover:bg-amber-200"
                  >
                    Unlock Premium
                  </button>
                </div>
              )}
            </section>
          </>
        ) : null}
      </section>
    </main>
  );
}

type StatCardProps = {
  icon: React.ReactNode;
  label: string;
  value: string;
  subtitle: string;
};

function StatCard({ icon, label, value, subtitle }: StatCardProps) {
  return (
    <article className="rounded-2xl border border-white/10 bg-slate-950/55 p-4 shadow-[0_10px_24px_rgba(0,0,0,0.15)] transition hover:-translate-y-0.5 hover:border-white/20">
      <div className="flex items-center justify-between text-slate-300">
        <span className="text-xs uppercase tracking-[0.16em]">{label}</span>
        {icon}
      </div>
      <p className="mt-3 text-2xl font-semibold text-white">{value}</p>
      <p className="text-sm text-slate-400">{subtitle}</p>
    </article>
  );
}

function AppLoader({ label }: { label: string }) {
  return (
    <div className="relative min-h-screen px-4 py-8 sm:px-8 lg:px-12">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_12%,rgba(26,147,111,0.18),transparent_42%),linear-gradient(150deg,#04161f_0%,#082633_48%,#0a1f2a_100%)]" />
      <div className="mx-auto flex min-h-[70vh] w-full max-w-7xl items-center justify-center">
        <div className="flex flex-col items-center gap-4 rounded-3xl border border-white/10 bg-slate-950/65 px-7 py-6 text-slate-100 shadow-[0_24px_55px_rgba(0,0,0,0.24)]">
          <div className="relative">
            <div className="h-12 w-12 rounded-full border-2 border-emerald-300/30" />
            <Loader2 size={24} className="absolute left-1/2 top-1/2 -ml-3 -mt-3 animate-spin text-emerald-300" />
          </div>
          <p className="text-sm tracking-wide text-slate-200">{label}</p>
        </div>
      </div>
    </div>
  );
}
