import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HabitForge | Gamified Habit Tracking",
  description:
    "HabitForge helps you build daily and weekly habits with streaks, XP, badges, and premium analytics.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
