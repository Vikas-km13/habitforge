import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <div className="relative min-h-screen px-4 py-8 sm:px-8 lg:px-12">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(circle_at_20%_12%,rgba(26,147,111,0.18),transparent_42%),linear-gradient(150deg,#04161f_0%,#082633_48%,#0a1f2a_100%)]" />
      <div className="mx-auto flex min-h-[70vh] w-full max-w-7xl items-center justify-center">
        <div className="flex flex-col items-center gap-4 rounded-3xl border border-white/10 bg-slate-950/65 px-7 py-6 text-slate-100 shadow-[0_24px_55px_rgba(0,0,0,0.24)]">
          <div className="relative">
            <div className="h-12 w-12 rounded-full border-2 border-emerald-300/30" />
            <Loader2
              size={24}
              className="absolute left-1/2 top-1/2 -ml-3 -mt-3 animate-spin text-emerald-300"
            />
          </div>
          <p className="text-sm tracking-wide text-slate-200">Loading HabitForge...</p>
        </div>
      </div>
    </div>
  );
}
