import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { createUserSchema } from "@/lib/validation";
import { ensureDemoUser, refreshUserGamification } from "@/lib/dashboard";

export async function GET() {
  await ensureDemoUser();

  const users = await prisma.user.findMany({
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      displayName: true,
      subscriptionTier: true,
      shareProgress: true,
      level: true,
      points: true,
    },
  });

  return ok({ users });
}

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  const result = createUserSchema.safeParse(body);

  if (!result.success) {
    return fail("Invalid user payload.", 422);
  }

  const user = await prisma.user.create({
    data: {
      displayName: result.data.displayName,
      email: result.data.email,
    },
    select: {
      id: true,
      displayName: true,
      subscriptionTier: true,
      shareProgress: true,
      level: true,
      points: true,
    },
  });

  await refreshUserGamification(user.id);

  return ok({ user }, 201);
}
