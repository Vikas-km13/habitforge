import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { createHabitSchema } from "@/lib/validation";
import { refreshUserGamification } from "@/lib/dashboard";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function GET(_: NextRequest, { params }: Params) {
  const { userId } = await params;

  const habits = await prisma.habit.findMany({
    where: { userId, isArchived: false },
    orderBy: { createdAt: "asc" },
  });

  return ok({ habits });
}

export async function POST(request: NextRequest, { params }: Params) {
  const { userId } = await params;
  const body = await request.json().catch(() => null);
  const result = createHabitSchema.safeParse(body);

  if (!result.success) {
    return fail("Invalid habit payload.", 422);
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    return fail("User not found.", 404);
  }

  const habit = await prisma.habit.create({
    data: {
      userId,
      name: result.data.name,
      description: result.data.description,
      frequency: result.data.frequency,
      targetCount: result.data.targetCount,
      color: result.data.color ?? "#1A936F",
    },
  });

  await refreshUserGamification(userId);

  return ok({ habit }, 201);
}
