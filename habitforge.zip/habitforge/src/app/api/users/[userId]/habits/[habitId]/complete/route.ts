import { NextRequest } from "next/server";
import { getStreakStats } from "@/lib/gamification";
import { ok, fail } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { completionSchema } from "@/lib/validation";
import {
  awardPointsForCompletion,
  getCompletionPeriodInfo,
  refreshUserGamification,
} from "@/lib/dashboard";

type Params = {
  params: Promise<{ userId: string; habitId: string }>;
};

export async function POST(request: NextRequest, { params }: Params) {
  const { userId, habitId } = await params;
  const body = await request.json().catch(() => null);
  const result = completionSchema.safeParse(body);

  if (!result.success) {
    return fail("Invalid completion payload.", 422);
  }

  const habit = await prisma.habit.findFirst({
    where: {
      id: habitId,
      userId,
      isArchived: false,
    },
  });

  if (!habit) {
    return fail("Habit not found.", 404);
  }

  const loggedAt = result.data.loggedAt ? new Date(result.data.loggedAt) : new Date();
  const { periodKey, periodStart } = getCompletionPeriodInfo(habit, loggedAt);

  const previousPeriodTotal = await prisma.completion.aggregate({
    where: {
      habitId,
      periodKey,
    },
    _sum: {
      amount: true,
    },
  });

  const previousAmount = previousPeriodTotal._sum.amount ?? 0;

  const completion = await prisma.completion.create({
    data: {
      userId,
      habitId,
      amount: result.data.amount,
      loggedAt,
      periodKey,
      periodStart,
    },
  });

  let pointsEarned = 0;
  const periodAmount = previousAmount + result.data.amount;
  const milestoneHit = previousAmount < habit.targetCount && periodAmount >= habit.targetCount;

  if (milestoneHit) {
    const completions = await prisma.completion.findMany({
      where: { habitId },
      select: {
        periodKey: true,
        periodStart: true,
        amount: true,
      },
    });

    const periodMap = new Map<string, { periodStart: Date; amount: number }>();
    for (const item of completions) {
      const current = periodMap.get(item.periodKey);
      if (!current) {
        periodMap.set(item.periodKey, {
          periodStart: item.periodStart,
          amount: item.amount,
        });
      } else {
        current.amount += item.amount;
      }
    }

    const completedPeriodStarts = Array.from(periodMap.values())
      .filter((entry) => entry.amount >= habit.targetCount)
      .map((entry) => entry.periodStart);

    const streakStats = getStreakStats(completedPeriodStarts, habit.frequency, loggedAt);

    pointsEarned = await awardPointsForCompletion({
      userId,
      habitId,
      streak: streakStats.current,
      reason:
        habit.frequency === "DAILY"
          ? `Daily milestone for ${habit.name}`
          : `Weekly milestone for ${habit.name}`,
    });
  }

  await refreshUserGamification(userId);

  return ok({
    completion,
    milestoneHit,
    pointsEarned,
  });
}
