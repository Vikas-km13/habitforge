import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { updateHabitSchema } from "@/lib/validation";

type Params = {
  params: Promise<{ userId: string; habitId: string }>;
};

export async function PATCH(request: NextRequest, { params }: Params) {
  const { userId, habitId } = await params;
  const body = await request.json().catch(() => null);
  const result = updateHabitSchema.safeParse(body);

  if (!result.success) {
    return fail("Invalid habit update payload.", 422);
  }

  const habit = await prisma.habit.findFirst({ where: { id: habitId, userId } });
  if (!habit) {
    return fail("Habit not found.", 404);
  }

  const updated = await prisma.habit.update({
    where: { id: habitId },
    data: result.data,
  });

  return ok({ habit: updated });
}

export async function DELETE(_: NextRequest, { params }: Params) {
  const { userId, habitId } = await params;

  const habit = await prisma.habit.findFirst({ where: { id: habitId, userId } });
  if (!habit) {
    return fail("Habit not found.", 404);
  }

  await prisma.habit.update({
    where: { id: habitId },
    data: { isArchived: true },
  });

  return ok({ success: true });
}
