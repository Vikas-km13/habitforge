import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { shareSchema } from "@/lib/validation";
import { refreshUserGamification } from "@/lib/dashboard";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function PATCH(request: NextRequest, { params }: Params) {
  const { userId } = await params;
  const body = await request.json().catch(() => null);
  const result = shareSchema.safeParse(body);

  if (!result.success) {
    return fail("Invalid share payload.", 422);
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    return fail("User not found.", 404);
  }

  const updated = await prisma.user.update({
    where: { id: userId },
    data: { shareProgress: result.data.shareProgress },
  });

  await refreshUserGamification(userId);

  return ok({
    user: {
      id: updated.id,
      shareProgress: updated.shareProgress,
    },
  });
}
