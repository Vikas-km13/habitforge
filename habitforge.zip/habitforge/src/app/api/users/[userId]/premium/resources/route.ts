import { getPremiumResources, requireUser } from "@/lib/dashboard";
import { ok, fail } from "@/lib/http";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function GET(_: Request, { params }: Params) {
  const { userId } = await params;

  const user = await requireUser(userId);
  if (!user) {
    return fail("User not found.", 404);
  }

  if (user.subscriptionTier !== "PREMIUM") {
    return fail("Premium subscription required.", 403);
  }

  return ok({ resources: getPremiumResources() });
}
