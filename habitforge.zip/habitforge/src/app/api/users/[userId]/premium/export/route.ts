import { exportUserCsv } from "@/lib/dashboard";
import { fail } from "@/lib/http";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function GET(_: Request, { params }: Params) {
  const { userId } = await params;

  const csv = await exportUserCsv(userId);
  if (!csv) {
    return fail("Premium subscription required.", 403);
  }

  return new Response(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="habitforge-export-${userId}.csv"`,
    },
  });
}
