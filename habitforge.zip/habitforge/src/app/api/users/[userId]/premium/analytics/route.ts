import { buildPremiumAnalytics } from "@/lib/dashboard";
import { ok, fail } from "@/lib/http";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function GET(_: Request, { params }: Params) {
  const { userId } = await params;

  const analytics = await buildPremiumAnalytics(userId);
  if (!analytics) {
    return fail("Premium subscription required.", 403);
  }

  return ok(analytics);
}
