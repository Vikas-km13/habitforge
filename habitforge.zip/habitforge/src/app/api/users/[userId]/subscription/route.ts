import { NextRequest } from "next/server";
import { ok, fail } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { subscriptionSchema } from "@/lib/validation";
import { refreshUserGamification } from "@/lib/dashboard";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function PATCH(request: NextRequest, { params }: Params) {
  const { userId } = await params;
  const body = await request.json().catch(() => null);
  const result = subscriptionSchema.safeParse(body);

  if (!result.success) {
    return fail("Invalid subscription payload.", 422);
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    return fail("User not found.", 404);
  }

  const updated = await prisma.user.update({
    where: { id: userId },
    data: {
      subscriptionTier: result.data.tier,
    },
  });

  await refreshUserGamification(userId);

  return ok({
    user: {
      id: updated.id,
      subscriptionTier: updated.subscriptionTier,
    },
  });
}
