import { ok, fail } from "@/lib/http";
import { buildDashboard, refreshUserGamification } from "@/lib/dashboard";

type Params = {
  params: Promise<{ userId: string }>;
};

export async function GET(_: Request, { params }: Params) {
  const { userId } = await params;

  await refreshUserGamification(userId);
  const payload = await buildDashboard(userId);

  if (!payload) {
    return fail("User not found.", 404);
  }

  return ok(payload);
}
