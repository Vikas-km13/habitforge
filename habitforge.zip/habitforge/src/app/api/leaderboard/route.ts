import { ok } from "@/lib/http";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const leaderboard = await prisma.user.findMany({
    where: { shareProgress: true },
    select: {
      id: true,
      displayName: true,
      level: true,
      points: true,
    },
    orderBy: [{ points: "desc" }, { level: "desc" }],
    take: 20,
  });

  return ok({ leaderboard });
}
